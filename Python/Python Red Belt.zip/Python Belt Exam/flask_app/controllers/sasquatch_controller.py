from flask_app import app
from flask import render_template,session,redirect,request
from flask_app.models.sasquatch_model import Sasquatch
from flask_app.models.user_model import User

@app.route('/sasquatch/new')
def new_sasquatch():
    if not 'user_id' in session:
        return redirect('/')
    return render_template('new_sasquatch.html')

@app.route('/sasquatch/<int:id>')
def one_sasquatch(id):
    if not 'user_id' in session:
        return redirect('/')
    sasquatch=Sasquatch.get_by_id({'id':id})
    return render_template('one_sasquatch.html',sasquatch=sasquatch)

@app.route('/sasquatch/<int:id>/edit')
def edit_sasquatch(id):
    if not 'user_id' in session:
        return redirect('/')
    sasquatch=Sasquatch.get_by_id({'id':id})
    return render_template('edit_sasquatch.html',sasquatch=sasquatch)


@app.route('/sasquatch/create',methods=['post'])
def create_sasquatch():
    if Sasquatch.validate(request.form):
        data={**request.form,"user_id":int(session['user_id'])}
        print("🦋🦋🦋🦋🦋🦋🦋🦋",data,"🦋🦋🦋🦋🦋🦋🦋🦋")
        db_return=Sasquatch.create(data)
        print(db_return)
        return redirect('/dashboard')
    return redirect ('/sasquatch/new')

@app.route('/sasquatch/update',methods=['post'])
def update_sasquatch():
    if Sasquatch.validate(request.form):
        data={**request.form}
        print("🦋🦋🦋🦋🦋🦋🦋🦋",data,"🦋🦋🦋🦋🦋🦋🦋🦋")
        Sasquatch.update(data)
        return redirect('/dashboard')
    return redirect (f'/sasquatch/{request.form["id"]}/edit')

@app.route('/sasquatch/<int:id>/destroy')
def destroy_sasquatch(id):
    if not 'user_id' in session:
        return redirect('/')
    Sasquatch.destroy({'id':id})
    return redirect("/dashboard")