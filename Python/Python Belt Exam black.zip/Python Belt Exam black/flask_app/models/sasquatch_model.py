from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DATABASE
from flask import flash
from flask_app.models import user_model

class Sasquatch:
    def __init__(self,data):
        self.id=data["id"]
        self.user_id=data["user_id"]
        self.location=data["location"]
        self.story=data["story"]
        self.date_seen=data["date_seen"]
        self.s_number=data["s_number"]
        self.poster=user_model.User.get_by_id({'id':self.user_id})
        self.i_believe=False
        self.skept=Sasquatch.show_skeptics({'id':self.id})
        
    
    @classmethod
    def create(cls,data):
        query="""INSERT INTO sasquatches 
                            (user_id,location,story,date_seen,s_number)
                            VALUES (%(user_id)s,%(location)s,%(story)s,%(date_seen)s,%(s_number)s);"""
        return connectToMySQL(DATABASE).query_db(query,data)
    
    @classmethod
    def get_all(cls):
        query="""SELECT * FROM sasquatches;"""
        results=connectToMySQL(DATABASE).query_db(query)
        all_sasquatches=[]
        for row in results:
            all_sasquatches.append(cls(row))
        return all_sasquatches
    
    @classmethod
    def get_by_id(cls,data):
        query="""SELECT * FROM sasquatches WHERE id=%(id)s;"""
        result=connectToMySQL(DATABASE).query_db(query,data)
        if result:
            return cls(result[0])
        return None
    
    @classmethod
    def check_skeptics(cls,data):
        query = """
                SELECT * FROM skeptics WHERE user_id = %(user_id)s AND sasquatch_id = %(sasquatch_id)s;"""
        result=connectToMySQL(DATABASE).query_db(query,data)
        if result:
            return True
        return False
    
    @classmethod
    def show_skeptics(cls,data):
        query="""
                SELECT user_id,skeptics.id FROM skeptics
                JOIN users ON user_id=skeptics.user_id
                Where skeptics.id=3;"""
        result=connectToMySQL(DATABASE).query_db(query,data)
        return result
    
    @classmethod
    def update(cls,data):
        print("🐝"*10, data,"🐝"*10)
        query=""" UPDATE sasquatches SET location=%(location)s,story=%(story)s,date_seen=%(date_seen)s,
                s_number=%(s_number)s WHERE id=%(id)s; """
        return connectToMySQL(DATABASE).query_db(query,data)
    @classmethod
    def destroy(cls,data):
        query="""DELETE FROM sasquatches WHERE id=%(id)s;"""
        return connectToMySQL(DATABASE).query_db(query,data)
    
    @classmethod
    def skeptic(cls,data):
        query = """
                INSERT INTO skeptics (user_id, sasquatch_id) VALUES (%(user_id)s, %(sasquatch_id)s)"""
        return connectToMySQL(DATABASE).query_db(query,data)
    
    @classmethod
    def believe(cls,data):
        query = """
                DELETE FROM skeptics WHERE user_id = %(user_id)s AND sasquatch_id = %(sasquatch_id)s)"""
        return connectToMySQL(DATABASE).query_db(query,data)
    
    @staticmethod
    def validate(data):
        is_valid=True
        if len(data['location'])<3:
            is_valid=False
            flash("The location is required")
        if len(data['story'])<3:
            is_valid=False
            flash("The story is required")
        if (data['date_seen'])=="":
            is_valid=False
            flash("Sighting Date must be provided")
        if int(data['s_number'])<1:
            is_valid=False
            flash("# of Sasquaches must be at least 1")
        return is_valid